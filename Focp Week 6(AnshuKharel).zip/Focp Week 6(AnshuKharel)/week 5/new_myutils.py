from my_utils import average
print("The avergae of number is",average([90,30,30]))